from .analysis import run_ccm_analysis_jupyter

__version__ = "1.12.0"  # WICHTIG: Muss mit setup.py übereinstimmen
